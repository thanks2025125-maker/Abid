const DAY_MS = 24 * 60 * 60 * 1000;
const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store"
};

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...JSON_HEADERS, ...extraHeaders }
  });
}

function corsHeaders() {
  // License verification is a public, non-cookie API. Restrict this further
  // to your known extension origins/domain if your deployment allows it.
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET, POST, OPTIONS",
    "access-control-allow-headers": "content-type, authorization",
    "access-control-max-age": "86400"
  };
}

function withCors(response) {
  const headers = new Headers(response.headers);
  for (const [k, v] of Object.entries(corsHeaders())) headers.set(k, v);
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers
  });
}

async function sha256(value) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
}

function randomLicenseKey() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  const raw = [...bytes].map(b => b.toString(16).padStart(2, "0")).join("").toUpperCase();
  return `LIC-${raw.match(/.{1,8}/g).join("-")}`;
}

async function readJson(request) {
  try {
    const value = await request.json();
    return value && typeof value === "object" && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

function validId(value) {
  return Number.isInteger(value) && value > 0;
}

async function audit(env, action, licenseId = null, details = "") {
  await env.DB.prepare(
    "INSERT INTO audit_logs (action, license_id, created_at, details) VALUES (?, ?, ?, ?)"
  ).bind(action, licenseId, Date.now(), String(details).slice(0, 500)).run();
}

async function requireAdmin(request, env) {
  const expected = env.ADMIN_TOKEN;
  const header = request.headers.get("authorization") || "";
  const supplied = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!expected || !supplied || supplied.length > 512) return false;

  // Hash both values before comparison to avoid early-exit string comparisons.
  const [a, b] = await Promise.all([sha256(expected), sha256(supplied)]);
  return a === b;
}

async function handleVerify(request, env) {
  const body = await readJson(request);
  const key = typeof body?.key === "string" ? body.key.trim() : "";
  const deviceId = typeof body?.deviceId === "string" ? body.deviceId.trim() : "";

  if (key.length < 12 || key.length > 200 || deviceId.length < 8 || deviceId.length > 200) {
    return json({ ok: false, code: "INVALID_INPUT", message: "A valid key and device ID are required." }, 400);
  }

  const [keyHash, deviceHash] = await Promise.all([sha256(key), sha256(deviceId)]);
  const row = await env.DB.prepare(
    "SELECT id, status, expires_at, device_hash FROM licenses WHERE key_hash = ?"
  ).bind(keyHash).first();

  if (!row) return json({ ok: false, code: "INVALID_KEY" }, 401);
  if (row.status !== "active") return json({ ok: false, code: "LICENSE_DISABLED" }, 403);
  if (row.expires_at <= Date.now()) return json({ ok: false, code: "LICENSE_EXPIRED" }, 403);

  const banned = await env.DB.prepare(
    "SELECT device_hash FROM banned_devices WHERE device_hash = ?"
  ).bind(deviceHash).first();
  if (banned) return json({ ok: false, code: "DEVICE_BANNED" }, 403);

  if (row.device_hash && row.device_hash !== deviceHash) {
    return json({ ok: false, code: "DEVICE_MISMATCH" }, 403);
  }

  if (!row.device_hash) {
    const result = await env.DB.prepare(
      "UPDATE licenses SET device_hash = ?, updated_at = ? WHERE id = ? AND device_hash IS NULL AND status = 'active' AND expires_at > ?"
    ).bind(deviceHash, Date.now(), row.id, Date.now()).run();

    // A concurrent activation may have won the race; reread and validate.
    const latest = await env.DB.prepare(
      "SELECT device_hash, status, expires_at FROM licenses WHERE id = ?"
    ).bind(row.id).first();
    if (!result.success || !latest || latest.device_hash !== deviceHash ||
        latest.status !== "active" || latest.expires_at <= Date.now()) {
      return json({ ok: false, code: "DEVICE_MISMATCH" }, 403);
    }
  }

  return json({ ok: true, expiresAt: row.expires_at, message: "License valid." });
}

async function handleAdmin(request, env, pathname) {
  if (!(await requireAdmin(request, env))) {
    return json({ ok: false, error: "Unauthorized" }, 401);
  }

  if (request.method === "GET" && pathname === "/api/admin/list") {
    const result = await env.DB.prepare(
      `SELECT id, status, expires_at, device_hash, created_at, updated_at
       FROM licenses ORDER BY created_at DESC LIMIT 500`
    ).all();
    return json({ ok: true, licenses: result.results || [] });
  }

  const body = await readJson(request);
  if (!body) return json({ ok: false, error: "Invalid JSON body" }, 400);

  if (request.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);

  if (pathname === "/api/admin/create") {
    const days = Number(body.days ?? 30);
    if (!Number.isInteger(days) || days < 1 || days > 3650) {
      return json({ ok: false, error: "days must be an integer from 1 to 3650" }, 400);
    }
    const key = randomLicenseKey();
    const now = Date.now();
    const expiresAt = now + days * DAY_MS;
    const keyHash = await sha256(key);
    const result = await env.DB.prepare(
      "INSERT INTO licenses (key_hash, status, expires_at, created_at, updated_at) VALUES (?, 'active', ?, ?, ?)"
    ).bind(keyHash, expiresAt, now, now).run();
    await audit(env, "license.create", result.meta?.last_row_id ?? null, `days=${days}`);
    // The plaintext key is returned only once. The database stores only its hash.
    return json({ ok: true, id: result.meta?.last_row_id, key, expiresAt }, 201);
  }

  if (pathname === "/api/admin/modify-time") {
    const id = Number(body.id);
    const daysDelta = Number(body.daysDelta);
    if (!validId(id) || !Number.isInteger(daysDelta) || daysDelta < -3650 || daysDelta > 3650 || daysDelta === 0) {
      return json({ ok: false, error: "Valid id and non-zero daysDelta (-3650..3650) required" }, 400);
    }
    const row = await env.DB.prepare("SELECT expires_at FROM licenses WHERE id = ?").bind(id).first();
    if (!row) return json({ ok: false, error: "License not found" }, 404);
    const base = Math.max(Date.now(), row.expires_at);
    const expiresAt = base + daysDelta * DAY_MS;
    await env.DB.prepare("UPDATE licenses SET expires_at = ?, updated_at = ? WHERE id = ?")
      .bind(expiresAt, Date.now(), id).run();
    await audit(env, "license.modify_time", id, `daysDelta=${daysDelta}`);
    return json({ ok: true, id, expiresAt });
  }

  if (pathname === "/api/admin/toggle") {
    const id = Number(body.id);
    const enabled = body.enabled;
    if (!validId(id) || typeof enabled !== "boolean") {
      return json({ ok: false, error: "id and boolean enabled required" }, 400);
    }
    const status = enabled ? "active" : "disabled";
    const result = await env.DB.prepare(
      "UPDATE licenses SET status = ?, updated_at = ? WHERE id = ?"
    ).bind(status, Date.now(), id).run();
    if (!result.meta?.changes) return json({ ok: false, error: "License not found" }, 404);
    await audit(env, `license.${status}`, id);
    return json({ ok: true, id, status });
  }

  if (pathname === "/api/admin/reset-device") {
    const id = Number(body.id);
    if (!validId(id)) return json({ ok: false, error: "Valid id required" }, 400);
    const result = await env.DB.prepare(
      "UPDATE licenses SET device_hash = NULL, updated_at = ? WHERE id = ?"
    ).bind(Date.now(), id).run();
    if (!result.meta?.changes) return json({ ok: false, error: "License not found" }, 404);
    await audit(env, "license.reset_device", id);
    return json({ ok: true, id });
  }

  if (pathname === "/api/admin/ban-device") {
    const id = Number(body.id);
    const banned = body.banned;
    const reason = typeof body.reason === "string" ? body.reason.slice(0, 300) : "Admin action";
    if (!validId(id) || typeof banned !== "boolean") {
      return json({ ok: false, error: "id and boolean banned required" }, 400);
    }
    const row = await env.DB.prepare("SELECT device_hash FROM licenses WHERE id = ?").bind(id).first();
    if (!row) return json({ ok: false, error: "License not found" }, 404);
    if (!row.device_hash) return json({ ok: false, error: "License has no bound device" }, 409);

    if (banned) {
      await env.DB.prepare(
        "INSERT INTO banned_devices (device_hash, reason, created_at) VALUES (?, ?, ?) ON CONFLICT(device_hash) DO UPDATE SET reason = excluded.reason"
      ).bind(row.device_hash, reason, Date.now()).run();
    } else {
      await env.DB.prepare("DELETE FROM banned_devices WHERE device_hash = ?").bind(row.device_hash).run();
    }
    await audit(env, banned ? "device.ban" : "device.unban", id, reason);
    return json({ ok: true, id, banned });
  }

  if (pathname === "/api/admin/delete") {
    const id = Number(body.id);
    if (!validId(id)) return json({ ok: false, error: "Valid id required" }, 400);
    const row = await env.DB.prepare("SELECT device_hash FROM licenses WHERE id = ?").bind(id).first();
    if (!row) return json({ ok: false, error: "License not found" }, 404);
    if (row.device_hash) {
      await env.DB.prepare("DELETE FROM banned_devices WHERE device_hash = ?").bind(row.device_hash).run();
    }
    await env.DB.prepare("DELETE FROM licenses WHERE id = ?").bind(id).run();
    await audit(env, "license.delete", id);
    return json({ ok: true, id });
  }

  return json({ ok: false, error: "Unknown admin endpoint" }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const pathname = url.pathname;

    if (request.method === "OPTIONS" && pathname.startsWith("/api/")) {
      return new Response(null, { status: 204, headers: corsHeaders() });
    }

    try {
      if (pathname === "/api/health" && request.method === "GET") {
        return withCors(json({ ok: true, service: "license-api" }));
      }

      if (pathname === "/api/license/verify" && request.method === "POST") {
        return withCors(await handleVerify(request, env));
      }

      if (pathname.startsWith("/api/admin/")) {
        return withCors(await handleAdmin(request, env, pathname));
      }

      // Serve the dashboard from the Worker Assets binding.
      if (pathname === "/" || pathname === "/admin") {
        const assetUrl = new URL(request.url);
        assetUrl.pathname = "/admin.html";
        return env.ASSETS.fetch(new Request(assetUrl, request));
      }
      if (pathname.startsWith("/api/")) return withCors(json({ ok: false, error: "Not found" }, 404));
      return env.ASSETS.fetch(request);
    } catch (error) {
      // Do not leak stack traces or secrets to clients.
      console.error("Request failed", error?.message || "unknown error");
      return withCors(json({ ok: false, error: "Internal server error" }, 500));
    }
  }
};
