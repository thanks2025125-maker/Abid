// Replace this with your deployed Worker URL (no trailing slash).
const API_BASE = "https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev";
const $ = id => document.getElementById(id);

function makeDeviceId() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
}
async function getDeviceId() {
  const data = await chrome.storage.local.get("deviceId");
  if (data.deviceId) return data.deviceId;
  const deviceId = makeDeviceId();
  await chrome.storage.local.set({deviceId});
  return deviceId;
}
async function verify() {
  const {licenseKey} = await chrome.storage.local.get("licenseKey");
  if (!licenseKey) {
    $("status").textContent = "Enter and save a license key first.";
    return;
  }
  if (API_BASE.includes("YOUR-WORKER")) {
    $("status").textContent = "Setup needed: edit API_BASE in popup.js and host_permissions in manifest.json.";
    return;
  }
  $("status").textContent = "Checking…";
  try {
    const deviceId = await getDeviceId();
    const response = await fetch(`${API_BASE}/api/license/verify`, {
      method: "POST",
      headers: {"content-type":"application/json"},
      body: JSON.stringify({key: licenseKey, deviceId})
    });
    const data = await response.json();
    if (response.ok && data.ok) {
      $("status").textContent = `License valid. Expires: ${new Date(data.expiresAt).toLocaleString()}`;
    } else {
      $("status").textContent = `License rejected: ${data.code || data.error || response.status}`;
    }
  } catch (error) {
    $("status").textContent = "Could not reach the license server. Check the Worker URL and network.";
  }
}
async function init() {
  const {licenseKey} = await chrome.storage.local.get("licenseKey");
  $("key").value = licenseKey || "";
}
$("save").addEventListener("click", async () => {
  const licenseKey = $("key").value.trim();
  if (!licenseKey) { $("status").textContent = "Enter a license key."; return; }
  await chrome.storage.local.set({licenseKey});
  await verify();
});
$("verify").addEventListener("click", verify);
init();
